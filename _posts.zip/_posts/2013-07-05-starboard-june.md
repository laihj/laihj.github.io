---
layout: post
title: "右舷201306"
description: ""
category: 
tags: [右舷]
---
{% include JB/setup %}

2013年6月。

右舷产品上花的时间:

iTimeLog 1小时36分

蓝黑之心 7小时11分

以上数据由[iTimeLog](https://itunes.apple.com/cn/app/itimelog/id423263073?l=en&mt=8)提供。

###蓝黑之心

蓝黑之心就发了两个版本，[做了些UI的小更新](http://starb.me/2013/06/08/nera19/)，[支持消息里晒看多个图片和手滑动手势返回上级](http://starb.me/2013/06/25/nera-20/)。

月中blog系统还出了点小问题。

这个月就是公司的活有点忙，在自己产品上花的时间变少了。

whosama跟过广州做游戏，祝好运。

今天下午，阵线发了条微博，对[接下来的发展询问意见](http://bbs.inter1908.net/showtopic-69960.html)，并提到蓝黑军团已经关闭了，不胜唏嘘，当年那么红火的论坛……

已经不是论坛的时代了，所以才做了蓝黑之心。
