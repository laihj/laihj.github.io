---
layout: post
title: "Goodbye Reader"
description: ""
category: 
tags: [闲扯]
---
{% include JB/setup %}

![byereader](http://interbbs.b0.upaiyun.com/byereader.jpg)

明天，Google就像正式关闭这个我每天都要用的服务。

再见，Google Reader。
