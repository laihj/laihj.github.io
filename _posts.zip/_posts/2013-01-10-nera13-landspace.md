---
layout: post
title: "蓝黑之心 1.3  伪直播，横屏以及其它"
description: ""
category: 
tags: [蓝黑之心]
---
{% include JB/setup %}

![live](http://ww3.sinaimg.cn/large/ad9e9b11jw1dztg473dlxj.jpg)

###直播模式

不要误会，我们还无法提供视频直播。所谓直播模式，其实是北看台的一种特殊模式。在进入直播摸式之后，北看台的界面将变大，隐去上下的功能栏，无须下拉操作，每分钟自动更新，并且iPhone不再自动黑屏。

这个模式其实是做给我自己用的，因为我喜欢一边看直播一边看微博吐槽。所以我一般会在比赛开始之后，打开直播模式，然后把iPhone放在一边，享受双屏快感。

###网页和视频支持横屏

![langspace](http://interbbs.b0.upaiyun.com/nera/landspace.png)


这是一个早就应该有的功能，当你查看网页或视频时，将iPhone或iPod touch横置，将适应横版界面，看到更大的视频显示。

###比赛分类

![match](http://interbbs.b0.upaiyun.com/nera/match.png)


随着比赛的增多，可能查看比赛会变得比较麻烦，于是在这一版，增加了比赛分类功能，在比赛界面，每场比赛的比赛会有比赛类型的标识，意甲、意杯、欧联、欧冠等。另外，点击上方的“比赛”字符，则对打开比赛选择菜单，以比赛进行筛选，查看特定类型的比赛会比较方便。

###积分榜小修

![score](http://interbbs.b0.upaiyun.com/nera/scoreboard.png)

小修改，显示欧冠区（黄），欧联区（红），降级区（黑）等标识。

在下一版，或下下版，积分榜还将继续进化

###其它更新:

UI修改。
