---
layout: post
title: "iTimeLog 2.2 输入提示"
description: ""
category: 
tags: [iTimeLog]
---
{% include JB/setup %}

新版发布，增加输入提示功能，如下图。

![imputcan](http://interbbs.b0.upaiyun.com/iTimeLog/input-can.png)

iTimeLog的输入提示，类似于中文输入法的输入提示，在您输入过程中，在键盘上方会出现输入候选栏，这时点击相应的事件，就可以完成输入。候选的事件资料来自您之前用iTimeLog进行的记录。

这个功能依然是为了方便输入，我们认为您之前输入过的事件是最好的输助输入材料，可以用来避免重复的工作。
