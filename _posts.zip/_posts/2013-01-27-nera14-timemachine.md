---
layout: post
title: "蓝黑之心 1.4  闪回 捐助"
description: ""
category: 
tags: [蓝黑之心]
---
{% include JB/setup %}

怎么也想不到苹果会在大周日的发审核通过的通知。

午安内拉，这版其实就加了一个功能，唤作闪回，闪回到比赛当天，看看比赛前后十二个小时都发生了什么，当时的欢笑和泪水，愤努与无奈。

蓝黑之心从去年8月开始，差不多时间就收集数据，这期间的比赛，我们都可以帮你闪回到现场，比如…….

![shudian](http://interbbs.b0.upaiyun.com/nera/shanhui1.png)

至于捐助，请随意，这是一个纯捐助的功能，不是保护费，也就是说交不交不会有功能或服务上的区别。

![luffy](http://interbbs.b0.upaiyun.com/nera/luffy.png)

蓝黑之心现在一天的服务器花费大概0.3元左右，所以只要新浪不死，应该还能为内拉服务很长时间，赏程序员两个子儿也算是鼓励了。