---
layout: post
title: "iTimeLog 2.1 编辑界面更新，备份新数据"
description: ""
category: 
tags: [iTimeLog]
---
{% include JB/setup %}

![editview](http://interbbs.b0.upaiyun.com/iTimeLog/editview.png)

iTimeLog2.1版更新两个功能。

1. 升级编辑事件界面，符合整体界面风格。

2. 备份恢复数据时包含模析，通知等设定，之前的版本只备份了记录的事件。

2.2版将会更新一个很好用的功能，代码已经写得差不多了，敬请期待:)
