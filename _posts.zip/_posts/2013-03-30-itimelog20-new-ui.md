---
layout: post
title: "iTimeLog 2.0 改头换面"
description: ""
category: 
tags: [iTimeLog]
---
{% include JB/setup %}

2.0版没有功能上的太多改动，主要是对界面进行了大修改，采用群众喜闻乐见的蓝色，希望摆脱之前界面较沉闷的观感。

不多说，直接上图。

![1cn](http://interbbs.b0.upaiyun.com/iTimeLog/1.cn.png)
![2cn](http://interbbs.b0.upaiyun.com/iTimeLog/2.cn.png)
![3cn](http://interbbs.b0.upaiyun.com/iTimeLog/3.cn.png)
![4cn](http://interbbs.b0.upaiyun.com/iTimeLog/4.cn.png)


除此之外，这一版正式去掉了切换背景图的功能。
